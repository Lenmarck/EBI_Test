# Teste EBI - Empresa XYZ

#Instalação:

Dependências:
```bash
pip3 install -r requirements.txt
```
Migração do bd:

```bash
python manage.py makemigrations
```
```bash
python manage.py migrate
```

#Execução
```bash
python manage.py runserver
```

